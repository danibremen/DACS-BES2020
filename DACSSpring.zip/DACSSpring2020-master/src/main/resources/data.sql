insert IGNORE into paciente(id,nome,sexo,data_nascimento) values(1,'zezinho','masculino','2020-07-08');
--insert IGNORE into usuario(id,usuario,senha) values(1,'admin','admin');
