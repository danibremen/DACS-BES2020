<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <?php
            var_dump($_GET);
        ?>
        
    </body>
</html>