<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        qualquer coisa aqui..
        <!-- Como mostrar uma mensagem em php--> 
        <?php
            $data = date("d.m.Y H:i:s", time());
            echo "<p align='center'> Hoje é: $data</p>";
        ?>
        
    </body>
</html>