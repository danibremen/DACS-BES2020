<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <?php
            function imprime($nome=""){
                echo "eu nao acredito: " . $nome;
                
            }
            
            imprime("Zezinho");
        
        ?>
    </body>
</html>