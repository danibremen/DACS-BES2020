<!DOCTYPE html>
 <!---Idioma do site -->
<html lang="pt-br">
    <head>
        <!---
        Caracterie brasileiro
        Titulo
        Link para uma pagina que será em css
        -->
        <meta charset="utf-8"/>
        <title>Projeto Login</title>
        <link rel="stylesheet" href="CSS/estilo.css"/>
    </head>
    <body>
    <!---Centralizar -->
    <div id="corpo-form">
        <h1>Entrar</h1>
         <!---Enviando senha -->
        <form method="POST" action="processa.php"/>
            <!---Placeholder = texto inserido dentro do campo que some quando digita no campo -->
            <input type="email" placeholder="usuario"/>
            <input type="password" placeholder="senha"/>
            <!---Botão -->
            <input type="submit" value="ACESSAR"/>
            <!---Strong para ficar em negrito -->
            <a href="">Ainda não é inscrito?<strong>Cadastre-se!</strong>/a>
            
        </form>
        </div>
    </body>
</html>